package com.project.jlm.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class Calender {

    public static String getCurrentDateAndTime() {
        // set the date format
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        // get calender instance
        Calendar cal = Calendar.getInstance();
        // return the formated date and time
        return dateFormat.format(cal.getTime());
    }
}
