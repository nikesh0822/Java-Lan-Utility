
package com.project.jlm.whiteboard.utils;

import java.awt.Color;


public class ContrastColor {

    public static Color getContrastColor(Color color) {
        // Counting the perceptive luminance - human eye favors green color... 
        double a = 1 - (0.299 * color.getRed() + 0.587 * color.getGreen() + 0.114 * color.getBlue()) / 255;

        if (a < 0.5) {
            return Color.BLACK; // bright colors - black font
        } else {
            return Color.WHITE; // dark colors - white font
        }
    }
}
