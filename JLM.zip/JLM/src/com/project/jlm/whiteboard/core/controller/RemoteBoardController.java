
package com.project.jlm.whiteboard.core.controller;

import com.project.jlm.core.message.Message;
import com.project.jlm.core.message.filters.FilterTypes;
import com.project.jlm.whiteboard.core.WhiteBoardInterface;
import java.awt.Color;
import java.awt.image.BufferedImage;


public class RemoteBoardController implements WhiteBoardInterface {

    // the control message object
    private Message controlMessage = null;

    /*
     * constructo with control message object as argument
     */
    public RemoteBoardController(Message message) {
        this.controlMessage = message;
    }

    /*
     * method to send draw command
     */
    public void drawOntoBoard(int x, int y) {
        controlMessage.sendMessage(""
                + (char) FilterTypes.CONTROL_FILTER
                + (char) CommandType.DRAW_ONTO_BOARD
                + (char) x
                + (char) y);
    }

    /*
     * method to send resize board command
     */
    public void resizeBoard(int width, int height) {
        controlMessage.sendMessage(""
                + (char) FilterTypes.CONTROL_FILTER
                + (char) CommandType.RESIZE_BOARD
                + (char) width
                + (char) height);
    }

    /*
     * method to send clear board command
     */
    public void clearBoard() {
        controlMessage.sendMessage(""
                + (char) FilterTypes.CONTROL_FILTER
                + (char) CommandType.CLEAR_BOARD);
    }

    /*
     * method to send board image command ####### NOT YET IMPLIMENTED ######
     */
    public void setBoardImage(BufferedImage boardImage) {

    }

  
    public void setChalkColor(Color chalkColor) {
        controlMessage.sendMessage(""
                + (char) FilterTypes.CONTROL_FILTER
                + (char) CommandType.SET_CHALK_COLOR
                + (char) chalkColor.getRed()
                + (char) chalkColor.getGreen()
                + (char) chalkColor.getBlue());
    }

    /*
     * method to send set chalk size command
     */
    public void setChalkSize(int chalkSize) {
        controlMessage.sendMessage(""
                + (char) FilterTypes.CONTROL_FILTER
                + (char) CommandType.SET_CHALK_SIZE
                + (char) chalkSize);
    }

    /*
     * method to send set board color command
     */
    public void setBoardColor(Color boardColor) {
        controlMessage.sendMessage(""
                + (char) FilterTypes.CONTROL_FILTER
                + (char) CommandType.SET_BOARD_COLOR
                + (char) boardColor.getRed()
                + (char) boardColor.getGreen()
                + (char) boardColor.getBlue());
    }

    // getter and setter for control message
    public Message getControlMessage() {
        return controlMessage;
    }

    public void setControlMessage(Message controlMessage) {
        this.controlMessage = controlMessage;
    }
}
