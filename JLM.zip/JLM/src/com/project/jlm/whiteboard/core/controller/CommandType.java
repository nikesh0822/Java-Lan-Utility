
package com.project.jlm.whiteboard.core.controller;

public final class CommandType {

    public static final int DRAW_ONTO_BOARD = 30000;
    public static final int RESIZE_BOARD = 30001;
    public static final int CLEAR_BOARD = 30002;
    public static final int SET_BOARD_IMAGE = 30003;
    public static final int SET_CHALK_COLOR = 30004;
    public static final int SET_CHALK_SIZE = 30005;
    public static final int SET_BOARD_COLOR = 30006;
}
