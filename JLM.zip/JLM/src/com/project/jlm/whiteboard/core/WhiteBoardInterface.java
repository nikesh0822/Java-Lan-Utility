
package com.project.jlm.whiteboard.core;

import java.awt.Color;
import java.awt.image.BufferedImage;

public interface WhiteBoardInterface {

    /*
     * method to draw onto the white board at location (x,y)
     */
    public void drawOntoBoard(int x, int y);

    /*
     * method to resize the board
     */
    public void resizeBoard(int width, int height);

    /*
     * method to clear the contents of the board
     */
    public void clearBoard();

    /*
     * method to set an image onto the board
     */
    public void setBoardImage(BufferedImage boardImage);

    /*
     * method to set the chalk color
     */
    public void setChalkColor(Color chalkColor);

    /*
     * method to set the chalk size
     */
    public void setChalkSize(int chalkSize);

    /*
     * method to set the board color
     */
    public void setBoardColor(Color boardColor);
}
