
package com.deepak.jlm.core.message.filters;


public final class FilterTypes {

    public static final int TEXT_FILTER = 40000;
    public static final int CONTROL_FILTER = 40001;
    public static final int TYPE_LOC_INDEX = 0;
}
