
package com.project.jlm.gui.components;

import com.project.jlm.core.message.Message;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;


public class ChatTextArea extends JTextArea implements PropertyChangeListener {

    // message object
    private Message message = null;

    // getter for message object
    public Message getMessage() {
        return message;
    }

    // setter for message object
    public void setMessage(Message message) {
        // set the reference message
        this.message = message;
        // add the chat text area as alistner to the message object
        // listining to message text change
        this.message.addPropertyChangeListener(this);
    }

    /*
     * method called on message text change to append the text message 
     * to the chat text area
     */
    public void propertyChange(PropertyChangeEvent evt) {
        this.append("\n" + this.message.getMessage());
    }

    /*
     * constructo fo the ChatTextArea class
     */
    public ChatTextArea() {
        // call super class default constructor
        super();
        // set auto scroll to the chat text area
        // so as to always display the last added message
        DefaultCaret caret = (DefaultCaret) this.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
    }
}
